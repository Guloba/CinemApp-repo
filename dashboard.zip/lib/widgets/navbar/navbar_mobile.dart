import 'package:flutter/material.dart';


class NavigationBarMobile extends StatelessWidget {
  final GlobalKey<ScaffoldState> scaffoldState;

  const NavigationBarMobile({Key key, this.scaffoldState}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
    );
  }
}